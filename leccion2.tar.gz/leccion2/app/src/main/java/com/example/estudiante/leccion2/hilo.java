package com.example.estudiante.leccion2;

/**
 * Created by estudiante on 25/08/16.
 */
public class hilo extends Thread {

    public hilo() {
    }

    public void run() {


    }
}
